# Creating a Character

## Mechanical basics

* DND Beyond Campaign: https://ddb.ac/campaigns/join/3756841775979428
* I'm good with any race/class combo you want
* Point Buy for Stats
* If you're doing something not "normal", talk to me first

## Basic Background Informtion

### What city / region / country are you from?

Feel free to create as much content here as you want!
- You can create a new nation, continent, city or town - tell me all about it!
- You can be from another city in the empire, pick a name and tell me what it's like!
- You can be from the capital of Kith - what district are you from? 

### What was/is your life like?

- What is your family like?
	- Who are notable members of your family
	- Are they alive? Still involved in your life?
- Where did you grow up? 
- What was your financial situation? What is it now?
- Any other important relationships in your life?
- Any important events or memories that helped you be the person you are today?

### When did you first know you were different from others? 

As an adventurer you are more skilled and capable of doing things others aren't. What happened to set you apart from others? 
* Did you make a deal with something to get power?
* Did a diety grant you powers in exchange for your devotion?
* Did you train super hard and turn your body into a weapon?
* etc

### Why would your character want to join [[The Order of the Ebon Eye]] ?

Give your character a reason that they would want to work with others for something bigger than themselves. Make sure your character wants to be here - this is a group game!


# Game Hook

You are really good at what you do, whether it's by accident, intent, inheritance or luck, and you've recently had an experience that allowed others to see you do that thing. Word has gotten around to someone in [[The Order of the Ebon Eye]], and you've just received an invitation to attend an event at The Gray Keep, in the heart of [[The City of Kith]]. 



