# The Empire

The Theocratic Empire of Kith is a powerful and deeply religious nation ruled by a council of high priests and priestesses, called The Watchers in White, who worship the deity known as The Steadfast Watcher. This god is revered as the ultimate guardian and protector, who watches over the empire and its citizens, providing safety, stability, and prosperity. Most importantly, The Steadfast Watcher is watching for any sign that The Maker of Chains is once again exerting her influence over the world.

The empire is close to a thousand years old, and has been slowly and inexorably expanding across the continent. It is largely seen as a good and just place to live, and the benefits of belonging to the empire are usually strong enough that adjacent territories are often petitioning for entry into the empire, as opposed to the early days of expansion that involved more direct persuasion from The Steadfast Legion.

The citizens of the empire are expected to lead lives of devotion to The Steadfast Watcher, attending regular religious ceremonies and making offerings to the temples. The church holds significant political power and influences many aspects of daily life, including the administration of justice and the management of the economy.

The empire is well-organized and efficient, with a strong military to protect its borders, called The Steadfast Legion. The soldiers of the empire wear distinctive holy symbols and are considered to be under the direct protection of The Steadfast Watcher. The architecture of the cities within the empire often features grand temples and religious monuments, and the streets are lined with statues and other symbols of the deity.

The Steadfast Watcher is believed to communicate directly with the high priests and priestesses of the empire, who use this communication to make decisions regarding the empire's future. These decisions are then carried out by the ruling council, which is composed of the most powerful and influential members of the church.

The Empire of Kith is one of the most prosperous and influential nations in the known world, and its citizens are proud of their devotion to their deity and their way of life.