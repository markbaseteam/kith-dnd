# The Steadfast Watcher and The Maker of Chains

In the beginning, there were two powerful twin wizards, Ardain and Amal Reilyr. They were born with an innate talent for magic and spent their entire lives honing their skills, becoming two of the most powerful practitioners of magic in all the land.

As they grew in power, the twins began to experiment with the creation of magical artifacts and spells, which soon led them to the brink of godhood. However, as they achieved ascension, the siblings' motivations began to diverge.

Amal was consumed by a desire for power and control, and she began to enslave entire nations, using her mastery of magic to forge magical chains that bound her subjects to her will. Ardain was horrified by his sister's actions and incited a rebellion against her, determined to put an end to her tyranny.

The siblings' conflict escalated into a full-scale war, with Ardain leading the charge against Amal and her armies of enchanted slaves. The war lasted for years, but in the end, Ardain emerged victorious, defeating his sister and using his magic to forge powerful bindings that would prevent her from ever threatening the world again.

Despite her defeat, Amal was not completely destroyed and her presence still lingers in the world as the diety The Maker of Chains, waiting for the day when she will break free from her bindings and reclaim her power. Adam remains vigilant, taking on the moniker of The Steadfast Watcher, constantly watching for any sign of his sister's return and preparing to defend the world against her wrath.