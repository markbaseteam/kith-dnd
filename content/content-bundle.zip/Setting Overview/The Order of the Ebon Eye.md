# The Order of the Ebon Eye

### Overview

The Order of the Ebon Eye is a secret organization composed of small groups of powerful adventurers. These groups operate in secrecy, traveling the world in search of powerful magical artifacts and investigating any events that may be related to The Maker of Chains, the powerful sorceress who threatened the world in the distant past.

The Order works closely with a government organization known as The Watchers in White, who provide them with support and resources in their mission to protect the world from supernatural threats. The two organizations have a close relationship, with members of The Order often working alongside agents of The Watchers in White to uncover the truth behind mysterious occurrences and recover powerful magical artifacts.

The members of The Order are highly skilled and experienced adventurers, chosen for their mastery of magic and their courage in the face of danger. They are equipped with the latest magic-enhancing technology and powerful magical artifacts, allowing them to face even the most powerful foes.

Despite their small size, The Order of the Ebon Eye is highly effective, feared by those who know of their existence for their tenacity and their willingness to use any means necessary to achieve their goals. They are constantly on the lookout for any signs of The Maker of Chains' return and work tirelessly to prevent her from breaking free of her bindings and reclaiming her power.

Despite their noble goals, The Order is not without its detractors. Some see them as a secretive and dangerous organization, using their power and influence to further their own aims at the expense of the greater good. Nevertheless, The Order remains steadfast in its mission, always vigilant, always watching, and always ready to face the unknown.



### Symbols Associated with The Order

![[EbonEyeSymbols.png]]