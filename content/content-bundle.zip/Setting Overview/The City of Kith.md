# The City of Kith

The city of Kith is a massive metropolis located in the heart of the empire. It is surrounded by towering walls, and serves as a hub for commerce, trade, and politics. The city is divided into several districts, each with its own unique character, from the elegant noble quarter to the gritty industrial district.

The city's central square is a hub of activity, centered around a grand temple dedicated to The Steadfast Watcher, and is the site of many public gatherings and events. The imperial palace sits atop a hill overlooking the city, and serves as the seat of power for the empress, Elyn Atrin.

The city is also home to numerous powerful guilds, representing various trades and crafts, as well as a criminal underworld controlled by several rival gangs. The city guard, comprised of soldiers and veterans, maintain order within the walls, but outside the walls, dangers such as raiders, monsters, and wild magic are common.

Despite its dangers, Kith is a thriving city filled with opportunities for adventure, wealth, and power.